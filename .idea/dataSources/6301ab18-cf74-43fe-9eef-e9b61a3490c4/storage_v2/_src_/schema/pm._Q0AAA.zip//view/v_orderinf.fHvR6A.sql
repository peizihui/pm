create view v_orderinf as
select `pm`.`t_user`.`user_name`       AS `user_name`,
       `pm`.`t_user`.`is_freeze`       AS `is_freeze`,
       `pm`.`t_goods`.`goods_name`     AS `goods_name`,
       `pm`.`t_goods`.`goods_price`    AS `goods_price`,
       `pm`.`t_orderstatus`.`os_type`  AS `os_type`,
       `pm`.`t_point`.`point_value`    AS `point_value`,
       `pm`.`t_order`.`order_id`       AS `order_id`,
       `pm`.`t_pointtype`.`point_type` AS `point_type`,
       `pm`.`t_order`.`create_date`    AS `create_date`,
       `pm`.`t_order`.`comp_date`      AS `comp_date`,
       `pm`.`t_user`.`id`              AS `user_ID`,
       `pm`.`t_order`.`id`             AS `o_ID`,
       `pm`.`t_goods`.`id`             AS `g_ID`,
       `pm`.`t_goods`.`goods_id`       AS `goods_ID`,
       `pm`.`t_orderstatus`.`id`       AS `os_ID`,
       `pm`.`t_point`.`id`             AS `point_ID`,
       `pm`.`t_pointtype`.`id`         AS `pt_ID`
from (((((`pm`.`t_user` join `pm`.`t_order` on ((`pm`.`t_order`.`user_id` = `pm`.`t_user`.`id`))) join `pm`.`t_goods` on ((`pm`.`t_order`.`g_id` = `pm`.`t_goods`.`id`))) join `pm`.`t_orderstatus` on ((`pm`.`t_order`.`os_id` = `pm`.`t_orderstatus`.`id`))) join `pm`.`t_point` on ((`pm`.`t_point`.`user_id` = `pm`.`t_user`.`id`)))
         join `pm`.`t_pointtype` on ((`pm`.`t_point`.`pt_id` = `pm`.`t_pointtype`.`id`)));

